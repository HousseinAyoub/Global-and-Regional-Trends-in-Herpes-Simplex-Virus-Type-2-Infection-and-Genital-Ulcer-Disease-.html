clear all;
close all;
clc

%----------------------Initialisation-------------------------------
 PoulationSize='DemFemaleGlobal1.xlsx';
B= xlsread(PoulationSize,5);
B=1000.*B;
%%%%%%Initialisation%%%%

%%%All logistic

%%%Guess parameter
% y=[0.0291801002580575;0.195408150035633;104.253096518108;1.79974227669884;8653.81436208289;0.461691126655452;0.197418136389482;197.822578441641];
% y=[0.026704257	1950.000193	110.0640404	14.85781066	7.517749337	0.846006926	1999.140737	74.15877061];

load('FemaleResultEURO.mat','Result')
y=Result;
% 
lb(1)=0;%0.00000001;
lb(2)=0;%0.1550;
lb(3)=0;%0.001;

ub(1)=Inf;%1;
ub(2)=Inf;%0.2100;
ub(3)=Inf;%10000;


lb(4)=0;%0.00000001;
lb(5)=0;%0.00000001;

ub(4)=Inf;%3.0;
ub(5)=20;%10000;


lb(6)=0;%0.00000001;
lb(7)=0;%0.19550;
lb(8)=0;%0.01;

ub(6)=Inf;%1;
ub(7)=Inf;%0.2100;
ub(8)=Inf;%10000;
% lb(1)=0.00000001;
% lb(2)=0.1550;
% lb(3)=0.001;
% 
% ub(1)=1;
% ub(2)=0.2100;
% ub(3)=10000;
% 
% 
% lb(4)=0.00000001;
% lb(5)=0.00000001;
% 
% ub(4)=3.0;
% ub(5)=10000;
% 
% 
% lb(6)=0.00000001;
% lb(7)=0.19550;
% lb(8)=0.01;
% 
% ub(6)=1;
% ub(7)=0.2100;
% ub(8)=10000;
 %Initialisation

 
options=optimset('Display','iter','TolFun',1e-8,'MaxIter',2000,'MaxFunEvals',2000);

tic
Result=fminsearchbnd(@MainEURO,y,lb,ub,options,B)
save('FemaleResultEURO.mat','Result')
toc

