clear all;
close all;
clc

%----------------------Initialisation-------------------------------
MalePoulationSize='DemMaleGlobal1.xlsx';
B= xlsread(MalePoulationSize,4);
B=1000.*B;
%%%%%%Initialisation%%%%
na=20;
%%%All logistic

%%%Guess parameter
y=[0.0151942701373146;0.197460111271682;120.390667735787;1.30026076459796;1013.00156359415;0.172660716954904;0.196355100102921;154.507970756259];

% load('MaleResultEMRO.mat','Result')
% y=Result;

lb(1)=0.01;
lb(2)=0;%1950;
lb(3)=0;

ub(1)=2;
ub(2)=Inf;%2100;
ub(3)=Inf;

lb(4)=0;%0.00000001;
lb(5)=0;%0.00000001;

ub(4)=Inf;%2.0;
ub(5)=20;%10000;

lb(6)=0;%0.00000001;
lb(7)=0;%0.1550;
lb(8)=0;%0.01;

ub(6)=Inf;%1;
ub(7)=Inf;%0.2100;
ub(8)=Inf;%10000;

 %Initialisation

 options=optimset('Display','iter','TolFun',1e-8,'MaxIter',20000,'MaxFunEvals',30000);
%  options=optimset('Display','iter','TolFun',1e-8,'MaxIter',2000,'MaxFunEvals',2000);

tic
Result=fminsearchbnd(@MainEMRO,y,lb,ub,options,B)
save('MaleResultEMRO.mat','Result')
toc

