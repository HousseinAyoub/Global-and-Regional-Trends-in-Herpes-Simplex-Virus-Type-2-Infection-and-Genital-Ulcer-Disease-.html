clear all;
close all;
clc

%----------------------Initialisation-------------------------------
 PoulationSize='DemFemaleGlobal1.xlsx';
B= xlsread(PoulationSize,8);
B=1000.*B;
%%%%%%Initialisation%%%%
%%%All logistic

%%%Guess parameter
% y=[0.0291801002580575;0.195408150035633;104.253096518108;1.79974227669884;8653.81436208289;0.461691126655452;0.197418136389482;197.822578441641];

load('FemaleResultUSA.mat','Result')
y=Result;

lb(1)=0.00000001;
lb(2)=0.1550;
lb(3)=0.001;

ub(1)=1;
ub(2)=0.2100;
ub(3)=10000;


lb(4)=0.00000001;
lb(5)=0.00000001;

ub(4)=3.0;
ub(5)=10000;


lb(6)=0.00000001;
lb(7)=0.19550;
lb(8)=0.01;

ub(6)=1;
ub(7)=0.2100;
ub(8)=10000;

 %Initialisation
options=optimset('Display','iter','TolFun',1e-8,'MaxIter',2000,'MaxFunEvals',2000);

tic
Result=fminsearchbnd(@MainUSA,y,lb,ub,options,B)
save('FemaleResultUSA.mat','Result')
toc

