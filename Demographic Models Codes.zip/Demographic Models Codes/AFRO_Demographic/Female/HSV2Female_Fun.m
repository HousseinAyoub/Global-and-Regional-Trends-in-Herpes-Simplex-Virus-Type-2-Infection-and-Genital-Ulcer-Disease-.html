function dydt=HSV2Female_Fun(t,x,b_0f,b_1f,b_2f,c_4f,c_3f,c_0f,c_1f,c_2f,na,nr)
%% Demographic parameters
tt=2100;
%% Variable names used in stating the ODEs
S_f=zeros(na,nr);

dS_fdt=zeros(na,nr);
%%
N_f=zeros(1,nr);

for a=1:na
    S_f(a,:)=x(nr*(a-1)+1:nr*a);
end
for i=1:nr
    N_fa=0;
    for a=1:na
        N_fa=N_fa+S_f(a,i);
    end
    N_f(i)=N_fa;
end
%%
mu_f=zeros(na,1);
eta=zeros(na,1);

beta_f=b_0f*exp(-((t-b_1f)/b_2f)^2);
for a=1:na
    mu_f(a)=c_0f*exp(-((t-c_1f)/c_2f)^2)/(1+exp(-c_3f*(a-c_4f)));
% eta
    if t<tt %1100 %1950
        eta(a)=1/5;
    else
        if a<20
            eta(a)=1/5;
        else
            eta(a)=0;
        end
   end 
end
%% The system
%% Female
dS_fdt(1,:)=beta_f*N_f-(eta(1)+mu_f(1))*S_f(1,:);
for a=2:na
    dS_fdt(a,:)=eta(a-1)*S_f(a-1,:)-(eta(a)+mu_f(a))*S_f(a,:);
end
%% Output
for a=1:na
    dydt(nr*(a-1)+1:nr*a)=dS_fdt(a,:);
end
dydt=dydt';
end
