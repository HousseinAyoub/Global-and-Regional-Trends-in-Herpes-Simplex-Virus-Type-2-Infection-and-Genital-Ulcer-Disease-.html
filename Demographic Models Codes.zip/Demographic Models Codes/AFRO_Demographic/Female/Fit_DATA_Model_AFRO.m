clear all;
close all;
clc

%----------------------Initialisation-------------------------------
FemalePoulationSize='DemFemaleGlobal1.xlsx';
B= xlsread(FemalePoulationSize,2);
B=1000.*B;
%%%%%%Initialisation%%%%
%%%All logistic

%%%Guess parameter
% y=[0.026704257	1950.000193	110.0640404	14.85781066	7.517749337	0.846006926	1999.140737	74.15877061];

load('FemaleResultAFRO.mat','Result')
y=Result;

lb(1)=0;%0.00000001;
lb(2)=0;%0.1550;
lb(3)=0;%0.001;

ub(1)=Inf;%1;
ub(2)=Inf;%0.2100;
ub(3)=Inf;%10000;


lb(4)=0;%0.00000001;
lb(5)=0;%0.00000001;

ub(4)=Inf;%3.0;
ub(5)=20;%10000;


lb(6)=0;%0.00000001;
lb(7)=0;%0.19550;
lb(8)=0;%0.01;

ub(6)=Inf;%1;
ub(7)=Inf;%0.2100;
ub(8)=Inf;%10000;

%Initialisation
options=optimset('Display','iter','TolFun',1e-8,'MaxIter',2000,'MaxFunEvals',3000);

tic
Result=fminsearchbnd(@MainAFRO,y,lb,ub,options,B)
save('FemaleResultAFRO.mat','Result')
toc

