function dydt = HSV2Male_Fun(t,y,b_0m,b_1m,b_2m,c_4m,c_3m,c_0m,c_1m,c_2m,na,nr)
%% Demographic parameters
tt=2100;
%% Variable names used in stating the ODEs
S_m=zeros(na,nr);

dS_mdt=zeros(na,nr);
%%
N_m=zeros(1,nr);

for a=1:na
    S_m(a,:)=y(nr*(a-1)+1:nr*a);
end
for i=1:nr
    N_ma=0;
    for a=1:na
        N_ma=N_ma+S_m(a,i);
    end
    N_m(i)=N_ma;
end
%%
mu_m=zeros(na,1);
eta=zeros(na,1);

beta_m=b_0m*exp(-((t-b_1m)/b_2m)^2);
for a=1:na
    mu_m(a)=c_0m*exp(-((t-c_1m)/c_2m)^2)/(1+exp(-c_3m*(a-c_4m)));
% eta
    if t<tt %1100 %1950
        eta(a)=1/5;
    else
        if a<20
            eta(a)=1/5;
        else
            eta(a)=0;
        end
   end 
end
%% The system
%% Male
dS_mdt(1,:)=beta_m*N_m-(eta(1)+mu_m(1))*S_m(1,:);
for a=2:na
    dS_mdt(a,:)=eta(a-1)*S_m(a-1,:)-(eta(a)+mu_m(a))*S_m(a,:);
end
%% Output
for a=1:na
    dydt(nr*(a-1)+1:nr*a)=dS_mdt(a,:);
end
dydt=dydt';
end