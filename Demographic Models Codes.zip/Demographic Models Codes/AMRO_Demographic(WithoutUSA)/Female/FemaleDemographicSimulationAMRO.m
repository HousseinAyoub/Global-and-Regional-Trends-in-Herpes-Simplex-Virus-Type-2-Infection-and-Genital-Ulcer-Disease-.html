clear all;
close all;
clc   
%% Parameters
nr=5;
na=20;
%% Data
load('FemaleResultAMRO.mat','Result')
y=Result;

FemalePoulationSize='DemFemaleGlobal1.xlsx';
BAMRO= xlsread(FemalePoulationSize,3);
BUSA= xlsread(FemalePoulationSize,8);
B=1000.*(BAMRO-BUSA);
%% Estimated parameters
%Gaussian distribution Birth
a1=y(1);
b1=y(2)*10^4;
c1=y(3);

%Mortality rate
b2=y(4)*10;
c2=y(5);

a3=y(6);
b3=y(7)*10^4;
c3=y(8);

y=[a1 b1 c1 b2 c2 a3 b3 c3];
y=y';

%% Initialization
t0=1750;
tf=2099.5; 
dt=0.5;
tspan=t0:dt:tf;

%Distribution of Population 
RiskGroupPopulationFactorsFemales=[0.1736,0.6828,0.0848,0.0299,0.0289];
N0=B(1,2:21)'*RiskGroupPopulationFactorsFemales;

for a=1:na
    Y0i(nr*(a-1)+1:nr*a)=N0(a,:);
end
%% Solution to the model

[T,Y] = ode23t(@(t,x)HSV2Female_Fun(t,x,a1,b1,c1,b2,c2,a3,b3,c3,na,nr),tspan,Y0i);


S_F=zeros(length(T),na);
SFsum=zeros(length(T)/2,na);

for a=1:na
    S_F(:,a)=sum(Y(:,nr*(a-1)+1:nr*a),2);
end

for a=1:na
    SFsum(t0-t0+1,a)=S_F(1,a);
end
for t=t0+1:2099
    for a=1:na 
        SFsum(t-t0+1,a)=trapz(S_F(2*(t-t0)+1:2*(t-t0+dt)+1,a));
    end
end

SFsumTot=sum(SFsum,2);
%%
cc=0;
differ=0;
cc4=0;
differ4=0;

for t=1950:5:2050
    for a=1:na
        differ=cc+((SFsum(t-t0+1,a)-B((t-1950)/5+1,a+1))/SFsum(t-t0+1,a))^2;
        cc=differ;
    end
end

Cost=differ+differ4
%% Ploting

figure;
title('AMRO Region')
% % %%%Total population size (Fig S1 appendix)
dtP=1950:2099;
hold on 
plot(dtP,SFsumTot(1950-t0+1:2099-t0+1),'r')
plot(BAMRO(1:31,1),B(1:31,23),'*') 
xlabel({'Year'})
ylabel({'Total Women population size'})

figure;
sgtitle('AMRO Region')
% %%%Total population size stratified by age group
subplot(331)
hold on
plot(SFsum(1950-t0+1,:),'r')
plot(B(1,2:21),'*')
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'})
xlabel({'Age group'})
ylabel({'Women population size'})
title('1950');

subplot(332)
hold on
plot(SFsum(1955-t0+1,:),'r')
plot(B(2,2:21),'*')
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'})
xlabel({'Age group'})
ylabel({'Women population size'})
title('1955');

subplot(333)
hold on
plot(SFsum(1960-t0+1,:),'r')
plot(B(3,2:21),'*')
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'})
xlabel({'Age group'})
ylabel({'Women population size'})
title('1960');

subplot(334)
hold on
plot(SFsum(1970-t0+1,:),'r')
plot(B(5,2:21),'*')
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'})
xlabel({'Age group'})
ylabel({'Women population size'})
title('1970');

subplot(335)
hold on
plot(SFsum(1980-t0+1,:),'r')
plot(B(7,2:21),'*')
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'})
xlabel({'Age group'})
ylabel({'Women population size'})
title('1980');

subplot(336)
hold on
plot(SFsum(1990-t0+1,:),'r')
plot(B(9,2:21),'*')
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'})
xlabel({'Age group'})
ylabel({'Women population size'})
title('1990');

subplot(337)
hold on
plot(SFsum(2010-t0+1,:),'r')
plot(B(13,2:21),'*')
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'})
xlabel({'Age group'})
ylabel({'Women population size'})
title('2010');

subplot(338)
hold on
plot(SFsum(2030-t0+1,:),'r')
plot(B(17,2:21),'*')
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'})
xlabel({'Age group'})
ylabel({'Women population size'})
title('2030');

subplot(339)
hold on
plot(SFsum(2050-t0+1,:),'r')
plot(B(21,2:21),'*')
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'})
xlabel({'Age group'})
ylabel({'Women population size'})
title('2050');
