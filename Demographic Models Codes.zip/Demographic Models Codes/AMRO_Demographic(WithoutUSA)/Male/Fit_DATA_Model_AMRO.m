clear all;
close all;
clc

%----------------------Initialisation-------------------------------
MalePoulationSize='DemMaleGlobal1.xlsx';
BAMRO= xlsread(MalePoulationSize,3);
BUSA= xlsread(MalePoulationSize,9);
B=1000.*(BAMRO-BUSA);
%%%%%%Initialisation%%%%
na=20;
%%%All logistic

%%%Guess parameter
% y=[0.0151942701373146;0.197460111271682;120.390667735787;1.30026076459796;1013.00156359415;0.172660716954904;0.196355100102921;154.507970756259];

load('MaleResultAMRO.mat','Result')
y=Result;

lb(1)=0.00000001;
lb(2)=0.1550;
lb(3)=0.01;

ub(1)=1;
ub(2)=0.2100;
ub(3)=10000;


lb(4)=0.00000001;
lb(5)=0.00000001;

ub(4)=2.0;
ub(5)=10000;


lb(6)=0.00000001;
lb(7)=0.1550;
lb(8)=0.01;

ub(6)=1;
ub(7)=0.2100;
ub(8)=10000;

 %Initialisation
 options=optimset('Display','iter','TolFun',1e-8,'MaxIter',20000,'MaxFunEvals',30000);

tic
Result=fminsearchbnd(@MainAMRO,y,lb,ub,options,B)
save('MaleResultAMRO.mat','Result')
toc

